%% 3D plot

 figure
for i = 1:size(cor_sam,2)
    h = ball(cor_sam(1,i)*pix_size,cor_sam(2,i)*pix_size,cor_sam(3,i)*pix_size,loopsize(i)*pix_size/2);
     set(h, 'linestyle','none')
    hold on
end 
axis equal
axis vis3d
grid off

% axis([-100 150 -150 100 -10 40])
% axis([-300 350 -350 300 -10 40])
camlight('headlight','infinite')
% scatter3(cor_sam(1,:)*pix_size,cor_sam(2,:)*pix_size,cor_sam(3,:)*pix_size,'ro')

%% plot the size and depth 
loopsize_max = max(loopsize)*pix_size;
loopsize_min = min(loopsize)*pix_size;
bin_length = ceil(loopsize_max)-floor(loopsize_min);
bin_size = 1;
bin_number = bin_length/bin_size;
loopdepth = -20:5:40;
loopsd = zeros(bin_number, size(loopdepth,2)-1);
for ij = 1:size(cor_sam,2)
    if cor_sam(3,ij)*pix_size >= min(loopdepth)&& cor_sam(3,ij)*pix_size <= max(loopdepth)
    loopsd_row = ceil(loopsize(ij)*pix_size-floor(loopsize_min));
    loopsd_col = ceil((cor_sam(3,ij)*pix_size -min(loopdepth))/5);
    loopsd(loopsd_row, loopsd_col) = loopsd(loopsd_row, loopsd_col)+1;
    end 
end 
figure;

subplot(2,2,1); subplot1 = imagesc(loopsd);

set(gca,'XTick',...
    [0.5 2.5  4.5  6.5  8.5  10.5  12.5],'XTickLabel',...
    {'-20','-10','0','10','20','30','40'},'YTick',...
    [0.5 1.5 2.5 3.5 4.5 5.5],'YTickLabel',{'1','2','3','4','5','6'});
xlabel('depth(nm)') % x-axis label
ylabel('dislocation loop size') % y-axis label

subplot(2,2,2);bar(sum(loopsd,1))
%% you can modify here to change the setup of the axis 
set(gca,'XTick',...
    [0.5 2.5  4.5  6.5 8.5  10.5  12.5],'XTickLabel',...
    {'-20','-10','0','10','20','30','40'});
xlabel('depth(nm)') % x-axis label
ylabel('number of dislocation loops') % y-axis label


subplot(2,2,3);bar(sum(loopsd,2))
set(gca,'XTick',...
    [0.5 1.5 2.5 3.5 4.5 5.5],'XTickLabel',{'1','2','3','4','5','6'});
xlabel('size of dislocation loops(nm)') % x-axis label
ylabel('number of dislocation loops') % y-axis label
    
    
%%%%%%%%%%%% end %%%%%%%%%%%%%%%%%
