%%%% 3D Tomogrpahy for dislocation loops
%% Introduction
%Copyright(c): Hongbing Yu @ University of Oxford (hongbing.yu@eng.ox.ac.uk) 
%Copyright(c): Felix Hofmann @ University of Oxford (felix.hofmann@eng.ox.ac.uk) 

% This code is used to reconstruct the 3D tomography of dislocation loops
% in ion irradiated metals. 

% The example TEM dark field images were acquired by Xiaoou Yi at IVEM, Argonne National Labtory.
% The sample is high purity tungsten (99.99%) thin foil irradiated by 150 kv 
% self ions at 30 K. The data was acquired at 300 k. 

% This program is free software; you can redistribute it and/or modify it under
% the terms of GNU GENERAL PUBLIC LICENSE

%To make the code work, make sure the 'bin' folder was included in the path.

%Images requirement :
%TEM bright filed or dark field images acquired under the same diffraction condition,
%that is, the g vector and the deviation parameter are maintained same during tilting. 

%The TEM Setup:
%The titling axis in the frame of the CCD camera must be calibrated. 

% Before running the code, please go through the input parameters 

%Acknowledgement: We acknowledge funding from the European Research Council (ERC) under the European
%Union�s Horizon 2020 research and innovation programme (grant agreement No 714697), 
%and funding from the Oxford University John Fell Fund (grant 161/054).  

% revised August 17,2017 H. Yu, Univerisyt of Oxford
%revised August 22, 2017 H. Yu, Univerisyt of Oxford  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% input parameters global
% please define the path for the images to be read and the data to be saved. 
clear;
impath = 'D:\Xiaoou Left Over\Code\Data_image'; %% the directory the images stored
datapath = impath; % the directory to save the intermediate computing data. Default is the directroy of the images. 
datsavfolder = 'Data_folder'; %%% the folder to which the intermediate date to be saved  
savnam = 'a2df'; %%% the name of the dataset                        
%% read in all images:%%%%%%%%%%%%%%%%%%%%%%%%%%
% please define what is the type of the images. 
% A spread sheet which record the tilting angle and the names of the images
% should be placed in the folder of the images. A specific format is
% required for the spreadsheet, which can be found in the example data
% foler. 
BOD = 1;   %%% Type of the TEM images, 1 for dark field iamges 0 for bright field images. 
imagetype = 'enhanced';  %%% original = DM3 original, enhanced = constrast enhanced by chopping the lower and upper limit
FDS = readtable([impath, '\', 'area2 datasheet.csv'],'Delimiter', ','); %%% table header should be  'xTilt_deg','yTilt _deg','MicrographName_number',
%%%....'DF','BF'. Image format should be tif. 'area2 datasheet.csv' is the
%%%name of the spread sheet. 

FDS_sort = sortrows(FDS);%%% please do not make any change in this line. 

%% Input parameters for background removal
% These parameters are used for background removal. 
% An iteration algrithom is used to remove the background of the image, to
% make the computor easier to detect the dislocation loops. 

t0 = 20; % approximate feature size in pixels divided by 2. This parameter is used for blurring

%%%% do not have to change the following lines if you are not an familiar
%%%% with code. 
t_step = 2; % step size in t...
dt = t_step./2; %step in t used for differentiation...
iter_n = 10; % the 10 iterations are usually good enough

%% Input parameters for image alignment
% These paremeters are used for the align all the images according to the
% roation center. The rotation center could be any loops in the images, but
% this loop should be visible in all the images. 

imref_al = 1; %% select the ith image as the reference image. 
ref_size = 40; %% The size of reference image, the value is depent on the size of the feature 


remfalse = 1;% % if the quality of the TEM images is not good. you may need to manually
% remove some false loop are loop fitting. input 1 if manual removal is
% required, 0 if the iamge quality is very good.  



xc_size = 2*ref_size;% the size of the area to be cross-correlated % do not have to change 


%% Input parameters for crops bad areas  
% This section invovles more human intervention dependent on the quality of
% the TEM iamges. If there are some obvious features which are not loops
% present in all the images, please select one image where the bad featuer
% is obvious to define the mask for cropping the bad features. 
imref_mask = 19;  %%% in which image you would like define the position of the mask 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Input parameters for loop fitting

tol = 200; %% the maximum number of loops you want to fit in each images(roughtly guess)
Nfitwin = 60; %% The size of the window where a loop to be fitted to 2D Gaussian function

% do not have to change 
W_in = 0; %% Index of Weighting
coefficient = 1.5; %%% coefficient*the RIDLER&CALVARD threshold of the image is the threshold we use seperate the loop and background 

%% Input parameters for loop identification

posz = -100:1:100;   %% define the depth for upper and lower surface relative the rotation center (unit is pixel). 
minimage = 7; % The minimum number of projections used, the default is 7
lswin = 8; % must be even , the size of the area a loop will be searched default is 10

% if some images are not good, then you may need to define which images you would like to
% use for reconstruction. 
imnum = [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19];
%% input parameters for TEM set up 

pix_size = 0.43;  %what is the size of each pixel in nm. 
altav = [cos((180-26)*pi/180), sin((180-26)*pi/180), 0]; %%the vector of the holder's alpha tilt axis in the frame of CCD camera
betav = [cos((90-26)*pi/180), sin((90-26)*pi/180), 0];   %%the vector of the holder's beta tilt axis in the frame of CCD camera
Holder = [altav;betav];

%% run the script 
Tomo_script1;

Tomo_plotfig;

% end 


